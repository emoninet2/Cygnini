/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef SI7006_H
#define SI7006_H

int si7006_verify_firmware_revision (void);
int si7006_read_humidity_and_temperature (uint16_t *humidity, uint16_t *temperature);

#define SI7006_ADDRESS								0x40

#define SI7006_FIRMWARE_REVISION					0x20

#define SI7006_MEASURE_RELATIVE_HUMIDITY_HOLD		0xE5
#define SI7006_MEASURE_RELATIVE_HUMIDITY_NO_HOLD	0xF5
#define SI7006_MEASURE_TEMPERATURE_HOLD				0xE3
#define SI7006_MEASURE_TEMPERATURE_NO_HOLD			0xF3
#define SI7006_READ_TEMPERATURE_FROM_PREVIOUS_RHM	0xE0
#define SI7006_RESET								0xFE
#define SI7006_READ_FIRMWARE_REVISION_1_2			0x84
#define SI7006_READ_FIRMWARE_REVISION_2_2			0xB8

#endif /* SI7006_H */