/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "si7006.h"

int si7006_verify_firmware_revision (void) {

	#define MAX_DATA_LENGTH 2

	uint8_t data[MAX_DATA_LENGTH] = {
		SI7006_READ_FIRMWARE_REVISION_1_2,
		SI7006_READ_FIRMWARE_REVISION_2_2
	};

	twi_package_t packet = {
		.addr_length = 0,
		.chip        = SI7006_ADDRESS,
		.buffer      = (void *)data,
		.length      = MAX_DATA_LENGTH,
		.no_wait     = false
	};

	if (twi_master_write(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
		 return EXIT_FAILURE;
	
	packet.length = 1;
	if (twi_master_read(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
		return EXIT_FAILURE;
	
	if (data[0] != SI7006_FIRMWARE_REVISION)
		return EXIT_FAILURE;
	
	return EXIT_SUCCESS;
}

int si7006_read_humidity_and_temperature (uint16_t *humidity, uint16_t *temperature) {	

	#define MAX_DATA_LENGTH		2
	#define MAX_READ_RETRIES	6

	int i;

	uint8_t data[MAX_DATA_LENGTH] = {
		SI7006_MEASURE_RELATIVE_HUMIDITY_NO_HOLD,
		0
	};

	twi_package_t packet = {
		.addr_length = 0,
		.chip        = SI7006_ADDRESS,
		.buffer      = (void *)data,
		.length      = 1,
		.no_wait     = false
	};

	if (twi_master_write(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
		return EXIT_FAILURE;
		
	packet.length = 2;
	for (i = MAX_READ_RETRIES; i > 0; i--) {
		
		if (twi_master_read(&TWI_MASTER_INTERFACE, &packet) == STATUS_OK) {
			
			*humidity = (uint16_t)((uint16_t)(data[0] << 8) + data[1]);
			
			packet.length = 1;
			data[0] = SI7006_READ_TEMPERATURE_FROM_PREVIOUS_RHM;
			if (twi_master_write(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
				return EXIT_FAILURE;
			
			packet.length = 2;	
			if (twi_master_read(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
				return EXIT_FAILURE;

			*temperature = (uint16_t)((uint16_t)(data[0] << 8) + data[1]);		
		
			return EXIT_SUCCESS;	
		}
	}
		
	return EXIT_FAILURE;
}
