/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */ 

#include "asf.h"
#include "low_power_radio.h"
#include "uart_rx_tx.h"

#define UART_FIFO_SIZE	256

struct fifo_s {
	uint8_t data[UART_FIFO_SIZE];
	uint8_t head;
	uint8_t tail;
	uint8_t count;
};

static volatile struct fifo_s uart_fifo = {
	.head = 0,
	.tail = 0,
	.count = 0
};

static struct fifo_s parsing_fifo = {
	.head = 0,
	.tail = 0,
	.count = 0
};

static struct message_s rx_message;

/*****************************************************************************/

int uart_send_message (struct message_s * tx_message) {

	if (usart_serial_write_packet(USART_DEBUG, tx_message->data, MESSAGE_LENGHT))
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
};
/*****************************************************************************/

int uart_message_poll (void) {

	int i;
	irqflags_t flags;
	
	/* Disable interrupts while popping data pushed to "uart_fifo" on RX interrupts */
	flags = cpu_irq_save();

	while (uart_fifo.count) {
		
		parsing_fifo.data[parsing_fifo.head] = uart_fifo.data[uart_fifo.tail];
			
		uart_fifo.tail = (((uart_fifo.tail)+1) % UART_FIFO_SIZE);
		uart_fifo.count--;
		
		parsing_fifo.head = (((parsing_fifo.head)+1) % UART_FIFO_SIZE);
		parsing_fifo.count++;
	}
	
	cpu_irq_restore(flags);
	
	while (parsing_fifo.count) {
	
		/* pop data until tail reaches the start of a new message */
		if (parsing_fifo.data[parsing_fifo.tail] != MESSAGE_START) {

			parsing_fifo.tail = (((parsing_fifo.tail)+1) % UART_FIFO_SIZE);
			parsing_fifo.count--;
			continue;
		}
	
		/* wait for complete message reception */
		if (parsing_fifo.count < MESSAGE_LENGHT)
			break;
		
		/* position for end of message */
		i = (((parsing_fifo.tail)+MESSAGE_LENGHT-1) % UART_FIFO_SIZE);
		
		/* verify end of message */
		if (parsing_fifo.data[i] != MESSAGE_END) {

			parsing_fifo.tail = (((parsing_fifo.tail)+MESSAGE_LENGHT) % UART_FIFO_SIZE);
			parsing_fifo.count -= MESSAGE_LENGHT;
			continue;
		}			
			
		/* copy the parsed message to the message_received struct */
		for (i=0; i<MESSAGE_LENGHT; i++) {
			rx_message.data[i] = parsing_fifo.data[(((parsing_fifo.tail)+i) % UART_FIFO_SIZE)];
		}

		/* handle received message */
		handle_received_message(MESSAGE_VIA_UART, &rx_message);		
					
		parsing_fifo.tail = (((parsing_fifo.tail)+MESSAGE_LENGHT) % UART_FIFO_SIZE);
		parsing_fifo.count -= MESSAGE_LENGHT;
		
	}
			
	return EXIT_SUCCESS;	
}
/*****************************************************************************/

ISR(USARTE0_RXC_vect) {
	
	/* if FIFO is full */
	if (uart_fifo.count > (UART_FIFO_SIZE-2))
		return;
						
	uart_fifo.data[uart_fifo.head] = USART_DEBUG_DATA;	
	uart_fifo.head = (((uart_fifo.head)+1) % UART_FIFO_SIZE);
	uart_fifo.count++;
}
