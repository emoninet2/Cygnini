/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef LPS25HB_H
#define LPS25HB_H

int lps25hb_verify (void);
int lps25_read_pressure_and_temperature (uint16_t *pressure, uint16_t *temperature);

#define LPS25HP_ADDRESS								0x5C

#define LPS25HP_WHO_AM_I_REGISTER					0x0F
#define LPS25HB_WHO_AM_I_EXPECTED_CONTENT			0xBD


#endif /* LPS25HB_H */