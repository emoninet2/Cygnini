/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "lps25hb.h"

int lps25hb_verify (void) {

	#define MAX_DATA_LENGTH 1

	uint8_t data[MAX_DATA_LENGTH] = {
		LPS25HP_WHO_AM_I_REGISTER
	};

	twi_package_t packet = {
		.addr_length = 0,
		.chip        = LPS25HP_ADDRESS,
		.buffer      = (void *)data,
		.length      = 1,
		.no_wait     = false
	};

	if (twi_master_write(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
		return EXIT_FAILURE;

	if (twi_master_read(&TWI_MASTER_INTERFACE, &packet) != STATUS_OK)
		return EXIT_FAILURE;

	if (data[0] != LPS25HB_WHO_AM_I_EXPECTED_CONTENT)
		return EXIT_FAILURE;

	return EXIT_SUCCESS;
}

int lps25_read_pressure_and_temperature (uint16_t *pressure, uint16_t *temperature) {	

	return EXIT_FAILURE;
}
