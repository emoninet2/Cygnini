/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef POWER_DOWN_H
#define POWER_DOWN_H

int power_down_enable (void);
int power_down_microcontroller (uint32_t seconds);

#endif /* POWER_DOWN_H */