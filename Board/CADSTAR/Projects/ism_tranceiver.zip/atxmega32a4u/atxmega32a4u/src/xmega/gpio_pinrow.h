/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef GPIO_PINROW_H
#define GPIO_PINROW_H

void status_gpio_inputs (uint8_t *status);
void status_gpio_outputs (uint8_t *status);

#endif /* GPIO_PINROW_H */