/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */ 

#include "asf.h"
#include "power_down.h"

static void alarm(uint32_t time) {
	
	nop();
	
}

int power_down_enable (void) {

	/* Enable power save mode, where the asynchronous real-time counter
		* counter continues to run
		*/
	sleepmgr_init();
	sleep_set_mode(SLEEP_SMODE_PSAVE_gc);
	rtc_init();
	rtc_set_callback(alarm);
	
	return EXIT_SUCCESS;
}


int power_down_microcontroller (uint32_t seconds) {

	rtc_set_alarm_relative(seconds);
	sleep_enable();
	sleep_enter();
	sleep_disable();
		
	return EXIT_SUCCESS;
}