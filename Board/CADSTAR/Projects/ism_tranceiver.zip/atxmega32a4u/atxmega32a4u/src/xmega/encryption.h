/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef ENCRYPTION_H
#define ENCRYPTION_H

int aes_encrypt(uint8_t *data);
int aes_decrypt(uint8_t *data);

#endif /* ENCRYPTION_H */