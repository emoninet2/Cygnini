/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "encryption.h"

int aes_encrypt(uint8_t *data) {
	
	uint8_t key[AES_KEY_SIZE] = {
		0x20, 0x80, 0x97, 0x1f, 0xe7, 0xda, 0x45, 0x06,
		0x3e, 0xa2, 0x57, 0x3c, 0x49, 0xb5, 0x69, 0x0c
	};
	
	sysclk_enable_module(SYSCLK_PORT_GEN, SYSCLK_AES);
	aes_software_reset();
	aes_configure(AES_ENCRYPT, AES_MANUAL, AES_XOR_OFF);

	aes_set_key(key);
	aes_write_inputdata(data);

	aes_start();

	do {
		
		if (aes_is_error())
			return EXIT_FAILURE;
		
	} while (aes_is_busy());

	aes_read_outputdata(data);

	return EXIT_SUCCESS;
}

int aes_decrypt(uint8_t *data) {
	
	uint8_t dummy_data[AES_KEY_SIZE] = {
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
		0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F
	};
	
	if (aes_encrypt(dummy_data))
		return EXIT_FAILURE;
		
	aes_configure(AES_DECRYPT, AES_MANUAL, AES_XOR_OFF);
	aes_write_inputdata(data);

	aes_start();

	do {
		
		if (aes_is_error())
			return EXIT_FAILURE;
		
	} while (aes_is_busy());

	aes_read_outputdata(data);

	return EXIT_SUCCESS;
}