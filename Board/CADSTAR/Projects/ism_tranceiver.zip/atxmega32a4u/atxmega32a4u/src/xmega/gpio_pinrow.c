/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "asf.h"
#include "gpio_pinrow.h"

void status_gpio_inputs (uint8_t *status) {

	*status = 0x00;
	
	if (ioport_get_pin_level(INPUT_EXT_1))
		*status += 0x01;
	
	if (ioport_get_pin_level(INPUT_EXT_2))
		*status += 0x02;
	
}

void status_gpio_outputs (uint8_t *status) {

	*status = 0x00;
	
	if (ioport_get_pin_level(OUTPUT_EXT_3))
		*status += 0x01;
}

ISR(INPUT_EXT_ISR) {
	
	ioport_set_pin_high(INDICATOR_LED);	
}
