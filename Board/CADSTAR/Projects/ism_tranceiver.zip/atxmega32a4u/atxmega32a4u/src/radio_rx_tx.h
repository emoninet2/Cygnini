/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef RADIO_RX_TX_H
#define RADIO_RX_TX_H

int radio_poll(void);
int radio_sleep (void);
int radio_enable_receive_mode(void);
int radio_send_message (struct message_s * tx_message);
								
#endif /* RADIO_RX_TX_H */