/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef SI4455_H
#define SI4455_H

int si4455_init (void);
int si4455_request_device_state (uint8_t *current_state);
int si4455_receiver_mode (void);
int si4455_transmitter_mode (void);
int si4455_transmit_variable_packet_lenght (uint8_t *data, uint8_t length);
int si4455_interrupt_handler (void);
int si4455_read_received_message(uint8_t *lenght, uint8_t max_lenght, uint8_t *data);
int si4455_standby (void);
int si4455_status (uint8_t *status);

#define SI4455_CHIP_ERROR												0xE1
#define SI4455_NO_CHANGE												0xA0
#define SI4455_MESSAGE_SENT												0xA1
#define SI4455_MESSAGE_RECEIVED											0xA2

#define SI4455_CMD_ID_WRITE_TX_FIFO										0x66
#define SI4455_CMD_ID_READ_RX_FIFO										0x77
#define SI4455_CMD_ID_READ_CMD_BUFF										0x44
#define SI4455_CMD_ID_EZCONFIG_CHECK									0x19

#define SI4455_CMD_ID_GET_INT_STATUS									0x20
#define SI4455_CMD_ARG_COUNT_GET_INT_STATUS								4
#define SI4455_CMD_REPLY_COUNT_GET_INT_STATUS							8

#define SI4455_CMD_GET_CHIP_STATUS_REP_CMD_ERROR_PEND_MASK				0x08

#define SI4455_CMD_ID_PART_INFO											0x01
#define SI4455_CMD_ARG_COUNT_PART_INFO									1
#define SI4455_CMD_REPLY_COUNT_PART_INFO								9

#define SI4455_CMD_ID_FIFO_INFO											0x15
#define SI4455_CMD_FIFO_INFO_ARG_RX_BIT									0x02
#define SI4455_CMD_ARG_COUNT_FIFO_INFO									2
#define SI4455_CMD_REPLY_COUNT_FIFO_INFO								2

#define SI4455_CMD_ID_START_TX											0x31
#define SI4455_CMD_ARG_COUNT_START_TX									5

#define SI4455_CMD_ID_START_RX											0x32
#define SI4455_CMD_ARG_COUNT_START_RX									8
#define SI4455_CMD_START_RX_ARG_RXINVALID_STATE_ENUM_RX					8
#define SI4455_CMD_START_RX_ARG_RXVALID_STATE_ENUM_RX					8
#define SI4455_CMD_START_RX_ARG_RXTIMEOUT_STATE_ENUM_NOCHANGE			0

#define SI4455_CMD_ID_REQUEST_DEVICE_STATE								0x33
#define SI4455_CMD_ARG_COUNT_REQUEST_DEVICE_STATE						1
#define SI4455_CMD_REPLY_COUNT_REQUEST_DEVICE_STATE						2
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_NOCHANGE	0
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_SLEEP		1
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_SPI_ACTIVE	2
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_READY		3
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_READY2		4
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_TX_TUNE		5
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_RX_TUNE		6
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_TX			7
#define SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_RX			8

#define SI4455_CMD_ID_CHANGE_STATE										0x34
#define SI4455_CMD_ARG_COUNT_CHANGE_STATE								2
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_NOCHANGE				0
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_SLEEP				1
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_SPI_ACTIVE			2
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_READY				3
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_READY2				4
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_TX_TUNE				5
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_RX_TUNE				6
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_TX					7
#define SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_RX					8

#endif /* SI4455_H */
