/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#include <asf.h>
#include "si4455.h"
#include "si4455_patch.h"
#include "si4455_radio_config.h"

static volatile uint8_t radio_status = SI4455_NO_CHANGE;

static struct spi_device spi_device_configuration = {
	.id = SI4455_nSEL
};

static struct interrupt_status_response_s {
	uint8_t  interrupt_pending;
	uint8_t  interrupt_status;
	uint8_t  packet_handler_pending;
	uint8_t  packet_handler_status;
	uint8_t  modem_pending;
	uint8_t  modem_status;
	uint8_t  chip_pending;
	uint8_t  chip_status;
} interrupt_status_response ;

enum packet_handler_interrupt_bit_positions_s {
	PACKET_RECEIVED = 0x10,
	PACKET_SENT	= 0x20
};

enum chip_interrupt_bit_positions_s {
	CHIP_ERROR = 0x08
};

static struct fifo_info_s {
	uint8_t rx_fifo_count;
	uint8_t tx_fifo_space;
} fifo_info;

static const uint8_t si4455_configuration[] = RADIO_CONFIGURATION_DATA_ARRAY;

/******************************************************************************/

static void si4455_write_single(uint8_t data) {
	
	nop();
	nop();
	nop();
	nop();	// TODO is this the correct timing?
	nop();
	nop();
	nop();
	nop();
	nop();
					
	spi_write_single(&SI4455_INTERFACE, data);
	while (!spi_is_rx_full(&SI4455_INTERFACE));
}

static int si4455_reset(void) {
	
	ioport_set_pin_level(SI4455_SHUT_DOWN, true);
	delay_ms(1);
	ioport_set_pin_level(SI4455_SHUT_DOWN, false);
	delay_ms(10);
	
	if (ioport_get_pin_level(SI4455_GPIO1) == false) {
		#ifdef USE_STANDARD_IO
			printf ("\r\nerror \"%s\" line %d.\r\n", __func__, __LINE__);
		#endif
		return EXIT_FAILURE;
	}
		
	return EXIT_SUCCESS;
}

static void si4455_write (bool poll_cts, uint8_t lenght, uint8_t *data) {

	if (poll_cts)
		while (ioport_get_pin_level(SI4455_GPIO1) == false);
		
	spi_select_device(&SI4455_INTERFACE, &spi_device_configuration);
	
	for (int i=0; i<lenght; i++)
		si4455_write_single(*(data+i));

	spi_deselect_device(&SI4455_INTERFACE, &spi_device_configuration);			
}

static int si4455_get_response (uint8_t lenght, uint8_t *data) {
	
	#define MAX_RETRIES	(100L)
	
	uint8_t response;
	int i;
	
	for (i=MAX_RETRIES; i>0; i--) {
		
		spi_select_device(&SI4455_INTERFACE, &spi_device_configuration);
		
		si4455_write_single(SI4455_CMD_ID_READ_CMD_BUFF);
		si4455_write_single(CONFIG_SPI_MASTER_DUMMY);	
		
		spi_read_single(&SI4455_INTERFACE, &response);		
		
		if (response != 0xff) {
			
			spi_deselect_device(&SI4455_INTERFACE, &spi_device_configuration);
			delay_us(100);
			continue;
		}
			
		if (lenght) {
			
			for (int i=0; i<lenght; i++) {
			
				si4455_write_single(CONFIG_SPI_MASTER_DUMMY);	
				spi_read_single(&SI4455_INTERFACE, &data[i]);
			}			
		
		}

		spi_deselect_device(&SI4455_INTERFACE, &spi_device_configuration);
		break;
	}
	
	if (i == 0) {
		#ifdef USE_STANDARD_IO
			printf ("\r\nerror \"%s\" line %d.\r\n", __func__, __LINE__);
		#endif
		return EXIT_FAILURE;		
	}
	
	return EXIT_SUCCESS;
}

/******************************************************************************/

static int si4455_get_int_status (uint8_t packet_handler_clear_pending, 
								  uint8_t modem_clear_pending,
								  uint8_t chip_clear_pending) {

	uint8_t data[SI4455_CMD_REPLY_COUNT_GET_INT_STATUS];
	
	data[0] = SI4455_CMD_ID_GET_INT_STATUS;
	data[1] = packet_handler_clear_pending;
	data[2] = modem_clear_pending;
	data[3] = chip_clear_pending;
	
	si4455_write (false, SI4455_CMD_ARG_COUNT_GET_INT_STATUS, data);
		
	if (si4455_get_response (SI4455_CMD_REPLY_COUNT_GET_INT_STATUS, data))
		return EXIT_FAILURE;

	interrupt_status_response.interrupt_pending = data[0];
	interrupt_status_response.interrupt_status = data[1];
	interrupt_status_response.packet_handler_pending = data[2];
	interrupt_status_response.packet_handler_status = data[3];
	interrupt_status_response.modem_pending = data[4];
	interrupt_status_response.modem_status = data[5];
	interrupt_status_response.chip_pending = data[6];
	interrupt_status_response.chip_status = data[7];
		
	return EXIT_SUCCESS;	
}

static int si4455_get_fifo_info(uint8_t argument) {
	
	uint8_t data[SI4455_CMD_REPLY_COUNT_GET_INT_STATUS];
	
	data[0] = SI4455_CMD_ID_FIFO_INFO;
	data[1] = argument;
	
	si4455_write (false, SI4455_CMD_ARG_COUNT_FIFO_INFO, data);
	
	if (si4455_get_response (SI4455_CMD_REPLY_COUNT_FIFO_INFO, data))
		return EXIT_FAILURE;

	fifo_info.rx_fifo_count = data[0];
	fifo_info.tx_fifo_space = data[1];

	return EXIT_SUCCESS;
}

static int si4455_verify_part(void) {
	
	enum part_information {
		
		PART_MSB = 1,
		PART_LSB,		
	};
	
	uint8_t data[SI4455_CMD_REPLY_COUNT_PART_INFO];
	
	data[0] = SI4455_CMD_ID_PART_INFO;
	
	si4455_write (true, SI4455_CMD_ARG_COUNT_PART_INFO, data);
	
	if (si4455_get_response (SI4455_CMD_REPLY_COUNT_PART_INFO, data))
		return EXIT_FAILURE;

	/* Verify */
	if ((data[PART_MSB] != 0x44) || (data[PART_LSB] != 0x55)) {
		#ifdef USE_STANDARD_IO
			printf ("\r\nerror \"%s\" line %d.\r\n", __func__, __LINE__);
		#endif
		return EXIT_FAILURE;
	}
	
	return EXIT_SUCCESS;
}

static int si4455_load_configuration(const uint8_t *configuration) {

	uint8_t lenght, response;
	
	while((lenght = *configuration++) > 0) {
			
		/* load array to the device */
		si4455_write(true, lenght, (uint8_t *)configuration);
				
		if (*configuration != SI4455_CMD_ID_WRITE_TX_FIFO) {
			
			if (si4455_get_response(1, &response))
				return EXIT_FAILURE;	
			
			if (*configuration == SI4455_CMD_ID_EZCONFIG_CHECK) {
			
				if (response) {
					#ifdef USE_STANDARD_IO
						printf ("\r\nerror \"%s\" line %d.\r\n", __func__, __LINE__);
					#endif
					return EXIT_FAILURE;
				}
			}
		}
		
		/* handle interrupts */
		if (ioport_get_pin_level(SI4455_nIRQ) == false) {

			if (si4455_get_int_status(0, 0, 0))
				return EXIT_FAILURE;
				
			if (interrupt_status_response.chip_pending & SI4455_CMD_GET_CHIP_STATUS_REP_CMD_ERROR_PEND_MASK)
				return EXIT_FAILURE;
		}
		    
		/* point to the next command */
		configuration += lenght;
    }
	
	return EXIT_SUCCESS;
}

static int si4455_start_rx(uint8_t channel, uint8_t condition, uint16_t rx_max_bytes, 
						   uint8_t next_state1, uint8_t next_state2, uint8_t next_state3) {
	
	uint8_t data[SI4455_CMD_REPLY_COUNT_GET_INT_STATUS];
	
	data[0] = SI4455_CMD_ID_START_RX;
	data[1] = channel;
	data[2] = condition;
	data[3] = (uint8_t)(rx_max_bytes >> 8);
	data[4] = (uint8_t)(rx_max_bytes >> 0);
	data[5] = next_state1;
	data[6] = next_state2;					
	data[7] = next_state3;
		
	si4455_write (false, SI4455_CMD_ARG_COUNT_START_RX, data);
	
	return EXIT_SUCCESS;
}

static int si4455_change_state(uint8_t next_state) {

	uint8_t data[SI4455_CMD_ARG_COUNT_CHANGE_STATE];
	
	data[0] = SI4455_CMD_ID_CHANGE_STATE;
	data[1] = next_state;	

	si4455_write(false, SI4455_CMD_ARG_COUNT_CHANGE_STATE, data);
	
	return EXIT_SUCCESS;
}

static int si4455_write_tx_fifo(uint8_t length, uint8_t *data) {

	//while (ioport_get_pin_level(SI4455_GPIO1) == false);
	
	spi_select_device(&SI4455_INTERFACE, &spi_device_configuration);
	
	si4455_write_single(SI4455_CMD_ID_WRITE_TX_FIFO);
	
	for (int i=0; i<length; i++)
		si4455_write_single(*(data+i));

	spi_deselect_device(&SI4455_INTERFACE, &spi_device_configuration);
	
	return EXIT_SUCCESS;
}

static int si4455_read_rx_fifo(uint8_t length, uint8_t *data) {

	//while (ioport_get_pin_level(SI4455_GPIO1) == false);
	
	spi_select_device(&SI4455_INTERFACE, &spi_device_configuration);
	
	si4455_write_single(SI4455_CMD_ID_READ_RX_FIFO);
	
	for (int i=0; i<length; i++) {
		si4455_write_single(CONFIG_SPI_MASTER_DUMMY);
		spi_read_single(&SI4455_INTERFACE, &data[i]);
	}

	spi_deselect_device(&SI4455_INTERFACE, &spi_device_configuration);
	
	return EXIT_SUCCESS;
}

static int si4455_start_tx(uint8_t channel, uint8_t condition, uint8_t tx_bytes) {

	uint8_t data[SI4455_CMD_ARG_COUNT_START_TX];
	
	data[0] = SI4455_CMD_ID_START_TX;
	data[1] = channel;
	data[2] = condition;
	data[3] = (uint8_t)(tx_bytes >> 8);
	data[4] = (uint8_t)(tx_bytes >> 0);

	si4455_write(false, SI4455_CMD_ARG_COUNT_START_TX, data);
	
	return EXIT_SUCCESS;
}

/******************************************************************************/

int si4455_init (void) {
		
	spi_master_init(&SI4455_INTERFACE);
	spi_master_setup_device(&SI4455_INTERFACE, &spi_device_configuration, SPI_MODE_0, SI4455_SPEED, 0);
	spi_enable(&SI4455_INTERFACE);
	
	if (si4455_reset())
		return EXIT_FAILURE;
		
	if (si4455_verify_part())
		return EXIT_FAILURE;	
	
 	/* load radio configuration */
 	if (si4455_load_configuration(si4455_configuration))
		return EXIT_FAILURE;
			
	return EXIT_SUCCESS;
}

int si4455_receiver_mode(void) {
	
	if (si4455_get_int_status(0, 0, 0))
		return EXIT_FAILURE;
		
	/* Reset RX FIFO */
	if (si4455_get_fifo_info(SI4455_CMD_FIFO_INFO_ARG_RX_BIT))
		return EXIT_FAILURE;
		
	if (si4455_start_rx(RADIO_CONFIGURATION_DATA_CHANNEL_NUMBER_DEFAULT, 0, 0,
						SI4455_CMD_START_RX_ARG_RXTIMEOUT_STATE_ENUM_NOCHANGE,
						SI4455_CMD_START_RX_ARG_RXVALID_STATE_ENUM_RX,
						SI4455_CMD_START_RX_ARG_RXINVALID_STATE_ENUM_RX))	
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}

int si4455_request_device_state (uint8_t *current_state) {

	uint8_t data[SI4455_CMD_REPLY_COUNT_REQUEST_DEVICE_STATE];
	
	data[0] = SI4455_CMD_ID_REQUEST_DEVICE_STATE;
	
	si4455_write (false, SI4455_CMD_ARG_COUNT_REQUEST_DEVICE_STATE, data);
	
	if (si4455_get_response (SI4455_CMD_REPLY_COUNT_REQUEST_DEVICE_STATE, data))
		return EXIT_FAILURE;
	
	*current_state = data[0];
	// TODO current channel not used data[1]

	return EXIT_SUCCESS;
}

int si4455_transmit_variable_packet_lenght(uint8_t *data, uint8_t length) {
	
	/* Leave RX state */
	if (si4455_change_state(SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_READY))
		return	EXIT_FAILURE;

	if (si4455_get_int_status(0, 0, 0))
		return EXIT_FAILURE;

	/* Reset the TX FIFO */
	if (si4455_get_fifo_info(SI4455_CMD_FIFO_INFO_ARG_RX_BIT))
		return EXIT_FAILURE;

	/* Fill the TX FIFO with data */
	if (si4455_write_tx_fifo(length, data))
		return EXIT_FAILURE;

	/* send packet immediately */
	if (si4455_start_tx(RADIO_CONFIGURATION_DATA_CHANNEL_NUMBER_DEFAULT, 0x80, length))
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}

int si4455_read_received_message(uint8_t *lenght, uint8_t max_lenght, uint8_t *data) {
	
    uint8_t read_count;

	/* Get payload length */
	si4455_get_fifo_info(0x00);

	*lenght = fifo_info.rx_fifo_count;
	read_count = fifo_info.rx_fifo_count;;

    if (fifo_info.rx_fifo_count > max_lenght)
        read_count = max_lenght;

	si4455_read_rx_fifo(read_count, data);
	
	return EXIT_SUCCESS;
}

int si4455_standby (void) {
	
	if (si4455_change_state(SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_SPI_ACTIVE))
		return EXIT_FAILURE;
	
	if (si4455_change_state(SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_SLEEP))
		return EXIT_FAILURE;	
		
	return EXIT_SUCCESS;
}

int si4455_interrupt_handler(void) {
	
	if (si4455_get_int_status(0, 0, 0))
		return EXIT_FAILURE;

	if (interrupt_status_response.chip_pending & CHIP_ERROR) {
		
		#ifdef USE_STANDARD_IO
			puts("chip error\r");
		#endif
		
		si4455_change_state(SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_SLEEP);
		
		/* Reset FIFO */
		si4455_get_fifo_info(SI4455_CMD_FIFO_INFO_ARG_RX_BIT);
		
		si4455_change_state(SI4455_CMD_CHANGE_STATE_ARG_NEW_STATE_ENUM_RX);
		
		radio_status = SI4455_CHIP_ERROR;
	}		
		
	if (interrupt_status_response.packet_handler_pending & PACKET_RECEIVED) {
		
		#ifdef USE_STANDARD_IO
			puts("message received\r");
		#endif
			
		radio_status = SI4455_MESSAGE_RECEIVED;
	}
		
		
	if (interrupt_status_response.packet_handler_pending & PACKET_SENT) {

		#ifdef USE_STANDARD_IO		
			puts("message sent\r");
		#endif
		
		radio_status = SI4455_MESSAGE_SENT;
	}
	
	#ifdef USE_STANDARD_IO		
		printf("%x, %x, %x, %x, %x, %x, %x, %x\r\n", interrupt_status_response.interrupt_pending,
													 interrupt_status_response.interrupt_status,
													 interrupt_status_response.packet_handler_pending,
													 interrupt_status_response.packet_handler_status,
													 interrupt_status_response.modem_pending,
													 interrupt_status_response.modem_status,
													 interrupt_status_response.chip_pending,
													 interrupt_status_response.chip_status);
	#endif
														 
	return EXIT_SUCCESS;	
}

int si4455_status (uint8_t *status) {

	*status = radio_status;
	radio_status = SI4455_NO_CHANGE;
	
	return EXIT_SUCCESS;
}
