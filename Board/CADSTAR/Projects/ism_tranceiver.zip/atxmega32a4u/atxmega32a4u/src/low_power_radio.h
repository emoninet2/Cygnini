/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#ifndef LOW_POWER_RADIO_H
#define LOW_POWER_RADIO_H

/* Number of second the sensor will sleep */
enum sensor_sleep_times_e {
	SENSOR_SLEEP = 900,
	SENSOR_SLEEP_WAITING_FOR_RESPONSE = 3
};

/* Transmit mode */
#define MESSAGE_VIA_UART						0x01
#define MESSAGE_VIA_RADIO						0x02

/* Fixed message defines */
#define MESSAGE_LENGHT							20
#define MESSAGE_START							0xaf
#define MESSAGE_END								0x5f

/* Communication model:
 *					|		    |
 * SERVICE USER		| SERVICE   |	SERVICE USER
 *					| PROVIDER  |
 *					|			|
 *	Request		    |			|	Indication
 *  -------------->	|			| -------------->
 *					|			|
 *  Confirmation	|			|	Response
 *	<--------------	|			| <--------------
 *					|			|
 *
 * Confirmation is the acknowledgment of the reception
 * of a request.
 *
 * Response is the acknowledgment of the reception
 * of an indication.
 *
 * Use of responses are not implemented.
 */

/* Addressing:
 *
 * All micro controllers generate their own 16-bit address
 * based on fabrication data.
 *
 * Messages with the receiver address set to 0x0000 are
 * routed to the UART interface of the Concentrator
 */

/* Indications */
#define MESSAGE_STATUS_INDICATION				0x30

/* Responses */
#define MESSAGE_STATUS_RESPONSE					0x31

/* Requests */
#define MESSAGE_GPIO_SET_REQUEST				0x33

/* Confirmations */
#define MESSAGE_GPIO_SET_CONFIRMATION			0x34

/* All UART and radio transmissions follow this structure */
struct message_s {
	union {
		struct {
			uint8_t start;
			uint8_t id;
			uint8_t receiver_address_msb;
			uint8_t receiver_address_lsb;			
			uint8_t sender_address_msb;
			uint8_t sender_address_lsb;
			uint8_t counter_msb;
			uint8_t counter_lsb;		
			uint8_t var_0;
			uint8_t var_1;
			uint8_t var_2;
			uint8_t var_3;
			uint8_t var_4;
			uint8_t var_5;
			uint8_t var_6;
			uint8_t var_7;
			uint8_t var_8;
			uint8_t crc_msb;
			uint8_t crc_lsb;
			uint8_t end;
		};
		uint8_t data[MESSAGE_LENGHT];
	};
};

#define MESSAGE_VALID_ALL					0x01						

int generate_microcontroller_name (void);
int handle_received_message (uint8_t medium, struct message_s * message);
int get_received_message_id (uint8_t *id);
int send_message (uint8_t message_id, uint8_t medium, bool encrypt);

#endif /* LOW_POWER_RADIO_H */