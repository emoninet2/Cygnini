/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "low_power_radio.h"
#include "xmega/power_down.h"
#include "uart_rx_tx.h"
#include "radio_rx_tx.h"

#include "lps25hb/lps25hb.h"

/* Refer to low_power_radio.h for configuration information and options */

int main (void) {
	
	uint8_t received_message_id;
	
	#if (defined CONCENTRATOR)
	
		#define CONCENTRATOR_TIMEOUT							300
		#define CONCENTRATOR_TIMEOUT_COUNT_BETWEEN_INDICATIONS  3000
		int timeout_counter = 0;
	
	#elif (defined SENSOR)
	
		enum sensor_states_e {
			SENSOR_IDLE,
			SENSOR_SLEEPING,
			SENSOR_SEND_INDICATION,
			SENSOR_INDICATION_SENT,
			SENSOR_INDICATION_RESENT,
			SENSOR_GO_TO_SLEEP,
		} sensor_state;
			
	#else
		#error Must be either concentrator or sensor
	#endif
		
	/* Configure GPIO, interfaces, and connected devices */
	if (init_hardware())
		error();
	
	/* Micro controller name is used as sender address, 
	 * and is based on unique production data
	 */
	if (generate_microcontroller_name())
		error();
		
	/*************************************************************************
	 * Concentrator:
	 *
	 * Forward sensor messages to higher level system via UART, and forward
	 * messages from higher level system to sensors
	 */
	#ifdef CONCENTRATOR
	
		#ifdef USE_STANDARD_IO
			puts("\n\rHardware initialized\r");
		#endif
		
		/* configure radio for reception */
		if (radio_enable_receive_mode())
			error();		
							
		while (true) {
			
			/* Handle messages received by uart */
			uart_message_poll();
			
			/* Handle messages received by radio */
			radio_poll();
			
			/* Respond to received messages */
			get_received_message_id(&received_message_id);
			switch(received_message_id) {

				case MESSAGE_GPIO_SET_REQUEST:
					send_message(MESSAGE_GPIO_SET_CONFIRMATION, MESSAGE_VIA_UART, false);
				case MESSAGE_STATUS_RESPONSE:		
				case MESSAGE_VALID_ALL:
					ioport_set_pin_high(INDICATOR_LED);
					break;
									
				default:
					break;
			}

			delay_ms(CONCENTRATOR_TIMEOUT);
			
			ioport_set_pin_low(INDICATOR_LED);
			
			/* Send indications at regular intervals */
			timeout_counter++;
			if ((timeout_counter % CONCENTRATOR_TIMEOUT_COUNT_BETWEEN_INDICATIONS) == 0)
				send_message(MESSAGE_STATUS_INDICATION, MESSAGE_VIA_UART, false);
		}
			
	#endif			

	/*************************************************************************
	 * Sensor:
	 *
	 * Wake up at SENSOR_SLEEP_TIME_SECONDS intervals to transmit indications
	 * via the concentrator to higher level system
	 */
	#ifdef SENSOR
		
		power_down_enable();
		sensor_state = SENSOR_IDLE;

		while (true) {
		
			switch(sensor_state) {
			
			default:
			case SENSOR_IDLE:
			case SENSOR_SLEEPING:
			
				ioport_set_pin_high(INDICATOR_LED);			
				sensor_state = SENSOR_SEND_INDICATION;
				break;
					
			case SENSOR_SEND_INDICATION:
			
				/* Transmit indication with GPIO status, temperature and humidity */
				send_message(MESSAGE_STATUS_INDICATION, MESSAGE_VIA_RADIO, true);
				radio_enable_receive_mode();
				ioport_set_pin_low(INDICATOR_LED);
				power_down_microcontroller(SENSOR_SLEEP_WAITING_FOR_RESPONSE);
				sensor_state = SENSOR_INDICATION_SENT;
				break;
				
			case SENSOR_INDICATION_SENT:
				
				radio_poll();
				
				/* Respond to received messages */
				get_received_message_id(&received_message_id);
				switch(received_message_id) {

					case MESSAGE_GPIO_SET_REQUEST:
						/* Retransmit indication with GPIO status, temperature and humidity */
						send_message(MESSAGE_GPIO_SET_CONFIRMATION, MESSAGE_VIA_RADIO, true);
						radio_enable_receive_mode();				
					case MESSAGE_STATUS_RESPONSE:
						sensor_state = SENSOR_GO_TO_SLEEP;
						break;

					default:
						/* Retransmit indication with GPIO status, temperature and humidity */
						send_message(MESSAGE_STATUS_INDICATION, MESSAGE_VIA_RADIO, true);
						radio_enable_receive_mode();
						ioport_set_pin_low(INDICATOR_LED);
						power_down_microcontroller(SENSOR_SLEEP_WAITING_FOR_RESPONSE);
						sensor_state = SENSOR_INDICATION_RESENT;
						break;					
				}
				break;

			case SENSOR_INDICATION_RESENT:
				
				radio_poll();
				sensor_state = SENSOR_GO_TO_SLEEP;							 
				break;
				
			case SENSOR_GO_TO_SLEEP:

				radio_sleep();
				ioport_set_pin_low(INDICATOR_LED);
				power_down_microcontroller(SENSOR_SLEEP);
				sensor_state = SENSOR_SLEEPING;	
				break;				
			}

		}
	
	#endif
	
	/*************************************************************************/
}