/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "low_power_radio.h"
#include "si7006/si7006.h"
#include "si4455/si4455.h"
#include "radio_rx_tx.h"
#include "uart_rx_tx.h"
#include "xmega/encryption.h"
/*****************************************************************************/

int init_hardware (void) {
		
	/* Wait for voltages to stabilize */
	delay_ms(200);
	
	sysclk_init();
	
	/* Real time clock from external 32kHz crystal */
	// TODO should be defined in conf_clock.h, but not working there
 	OSC.XOSCCTRL = OSC_XOSCSEL_32KHz_gc;
 	OSC.CTRL |= OSC_XOSCEN_bm;
 	while(!(OSC.STATUS&OSC_XOSCRDY_bm));
	CLK.RTCCTRL = CLK_RTCSRC_TOSC_gc | CLK_RTCEN_bm;
	
	ioport_init();
	
	/* GPIO */
	ioport_set_pin_dir(INPUT_EXT_1, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(INPUT_EXT_1, IOPORT_MODE_PULLDOWN);
	
	ioport_set_pin_dir(INPUT_EXT_2, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(INPUT_EXT_2, IOPORT_MODE_PULLDOWN);
	
	ioport_set_pin_dir(OUTPUT_EXT_3, IOPORT_DIR_OUTPUT);
	
	INPUT_EXT_PORT.INT0MASK = INPUT_EXT_PIN_MASK;
	INPUT_EXT_PORT.INTCTRL = PORT_INT0LVL_LO_gc;
	
	/* LED */
	ioport_set_pin_dir(INDICATOR_LED, IOPORT_DIR_OUTPUT);
	
	/* Unused pins */
	ioport_set_pin_dir(UNUSED_PIN_0, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_0, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_1, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_1, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_2, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_2, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_3, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_3, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_4, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_4, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_5, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_5, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_6, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_6, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_7, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_7, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_8, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_8, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_9, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_9, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_10, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_10, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_11, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_11, IOPORT_MODE_PULLDOWN);
	ioport_set_pin_dir(UNUSED_PIN_12, IOPORT_DIR_INPUT);
	ioport_set_pin_mode(UNUSED_PIN_12, IOPORT_MODE_PULLDOWN);				

	/* UART */
	const usart_serial_options_t usart_debug_options = {
		.baudrate = USART_DEBUG_BAUDRATE,
		.charlength = USART_DEBUG_CHAR_LENGTH,
		.paritytype = USART_DEBUG_PARITY,
		.stopbits = USART_DEBUG_STOP_BIT
	};
	
	#ifdef CONCENTRATOR

		ioport_set_pin_dir(USART_DEBUG_TX_PIN, IOPORT_DIR_OUTPUT);
		ioport_set_pin_dir(USART_DEBUG_RX_PIN, IOPORT_DIR_INPUT);
		
		#ifdef USE_STANDARD_IO
			stdio_serial_init(USART_DEBUG, &usart_debug_options);
		#else
			usart_serial_init((USART_t *)&USARTE0, &usart_debug_options);
		#endif
		
		usart_set_rx_interrupt_level(USART_DEBUG, USART_INT_LVL_LO);
		
	#elif (defined SENSOR)
	
		ioport_set_pin_dir(USART_DEBUG_TX_PIN, IOPORT_DIR_INPUT);
		ioport_set_pin_mode(USART_DEBUG_TX_PIN, IOPORT_MODE_PULLDOWN);
		ioport_set_pin_dir(USART_DEBUG_RX_PIN, IOPORT_DIR_INPUT);
		ioport_set_pin_mode(USART_DEBUG_RX_PIN, IOPORT_MODE_PULLDOWN);	
		
	#endif
	
	/* Two wire interface */
	twi_options_t twi_master_options = {
		.speed     = TWI_MASTER_SPEED,
		.chip      = TWI_MASTER_ADDRESS,
		.speed_reg = TWI_BAUD(sysclk_get_cpu_hz(), TWI_MASTER_SPEED)
	};
	
	TWI_MASTER_PORT.PIN0CTRL = PORT_OPC_WIREDANDPULL_gc;
	TWI_MASTER_PORT.PIN1CTRL = PORT_OPC_WIREDANDPULL_gc;
	sysclk_enable_peripheral_clock(&TWI_MASTER_INTERFACE);
	twi_master_init(&TWI_MASTER_INTERFACE, &twi_master_options);
	twi_master_enable(&TWI_MASTER_INTERFACE);
	
	if (si7006_verify_firmware_revision())
	return EXIT_FAILURE;
	
	/* SPI */
	ioport_set_pin_dir(SI4455_GPIO0, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(SI4455_GPIO1, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(SI4455_GPIO2, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(SI4455_GPIO3, IOPORT_DIR_INPUT);
	
	ioport_set_pin_dir(SI4455_SHUT_DOWN, IOPORT_DIR_OUTPUT);
	ioport_set_pin_dir(SI4455_nSEL, IOPORT_DIR_OUTPUT);
	ioport_set_pin_dir(SI4455_SDI, IOPORT_DIR_OUTPUT);
	ioport_set_pin_dir(SI4455_SDO, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(SI4455_SCLK, IOPORT_DIR_OUTPUT);
	ioport_set_pin_dir(SI4455_nIRQ, IOPORT_DIR_INPUT);
	SI4455_nIRQ_PORT.INT0MASK = SI4455_nIRQ_PIN_MASK;
	SI4455_nIRQ_PORT.INTCTRL = PORT_INT0LVL_LO_gc;
	SI4455_nIRQ_PORT.SI4455_nIRQ_PIN_CTRL = IOPORT_SENSE_FALLING;
	
	ioport_set_pin_level(SI4455_nSEL, true);
	ioport_set_pin_level(SI4455_SCLK, false);
	
	if (si4455_init())
		return EXIT_FAILURE;
	
	pmic_init();
	cpu_irq_enable();
	
	return EXIT_SUCCESS;
}
/*****************************************************************************/

void error (void) {
	
	while (true) {
		
		delay_ms(100);
		ioport_toggle_pin_level(INDICATOR_LED);
	}
}