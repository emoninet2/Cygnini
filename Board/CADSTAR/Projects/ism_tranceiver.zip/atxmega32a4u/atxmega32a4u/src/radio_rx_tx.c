/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */
#include <asf.h>
#include "low_power_radio.h"
#include "radio_rx_tx.h"
#include "si4455/si4455.h"

static struct message_s rx_message;

/*****************************************************************************/

int radio_enable_receive_mode(void) {
	
	#define MAX_RETRIES 40
	
	int i = MAX_RETRIES;
	uint8_t state;
	
	while (i) {
		
		delay_ms(10);
				
		if (si4455_request_device_state(&state))
			return EXIT_FAILURE;
			
		switch (state) {
			
		default:
			i = 0;
			break;
					
		case SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_TX:
		case SI4455_CMD_REQUEST_DEVICE_STATE_REP_MAIN_STATE_ENUM_TX_TUNE:
			delay_ms(10);
			i--;
			break;		
		}
	}
	
	if (si4455_receiver_mode())
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}	
/*****************************************************************************/
	
int radio_send_message (struct message_s * tx_message) {

	if (si4455_transmit_variable_packet_lenght(tx_message->data, MESSAGE_LENGHT))
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}
/*****************************************************************************/

int radio_poll (void) {
	
	uint8_t status, message_lenght;
	 
	si4455_status(&status);
	
 	if (status == SI4455_MESSAGE_RECEIVED) {
 				 
 		si4455_read_received_message(&message_lenght, MESSAGE_LENGHT, rx_message.data);
		
		if (message_lenght != MESSAGE_LENGHT) {
			
			#ifdef USE_STANDARD_IO
				puts("message length error\r");
			#endif
		}
		 		 
 		handle_received_message (MESSAGE_VIA_RADIO, &rx_message);

        if (radio_enable_receive_mode())
            return EXIT_FAILURE;
		  
 	}
	
	return EXIT_SUCCESS;
}

int radio_sleep (void) {
	
	if (si4455_standby())
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}

ISR(SI4455_nIRQ_ISR) {
	
	si4455_interrupt_handler();
}
