/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include <asf.h>
#include "low_power_radio.h"
#include "si7006/si7006.h"
#include "si4455/si4455.h"
#include "radio_rx_tx.h"
#include "uart_rx_tx.h"
#include "xmega/encryption.h"
#include "xmega/gpio_pinrow.h"

static uint16_t microcontroller_name = 0;
static uint16_t uart_tx_counter = 0;
static uint16_t radio_tx_counter = 0;

static uint8_t latest_message_id = 0;

/*****************************************************************************/

int get_received_message_id (uint8_t *id) {
	
	*id = latest_message_id;
	latest_message_id = 0;
	
	return EXIT_SUCCESS;
}

/*****************************************************************************/

int handle_received_message (uint8_t medium, struct message_s * message) {

	uint16_t message_recipient;
	
	latest_message_id = MESSAGE_VALID_ALL;
	
	/* Messages sent via radio are encrypted */
	if (medium == MESSAGE_VIA_RADIO) {
		
		if (aes_decrypt(&(message->data[1])))
			return EXIT_FAILURE;
	}
		
	message_recipient = (uint16_t)(message->receiver_address_msb << 8);
	message_recipient |= (uint16_t)(message->receiver_address_lsb << 0);
	
	/* Message is for me */
	if (microcontroller_name == message_recipient) {
		
		switch (message->id) {
			
		default:
			break;
			
		case MESSAGE_STATUS_RESPONSE:
			latest_message_id = MESSAGE_STATUS_RESPONSE;
			break;
			
		case MESSAGE_GPIO_SET_REQUEST:
			latest_message_id = MESSAGE_GPIO_SET_REQUEST;
			
			/* Set output according to content in message var_2 variable */
			if (message->var_2) {
				ioport_set_pin_high(OUTPUT_EXT_3);
			} else {
				ioport_set_pin_low(OUTPUT_EXT_3);
			}			
			break;
		}
		
	} else {
		
		/* Concentrator will forward messages */
		#ifdef CONCENTRATOR
		
	
			/* Message was received by UART. Encrypt and forward by radio */
			if (medium == MESSAGE_VIA_UART) {
				
				if (aes_encrypt(&(message->data[1])))
					return EXIT_FAILURE;

				if (radio_send_message(message))
					return EXIT_FAILURE;
			
				delay_ms(100); // TODO when to change state?
				radio_enable_receive_mode();				
		
			} else {
				
				if (uart_send_message(message))
					return EXIT_FAILURE;				
				
			}
			
		#endif
		
	}
	
	return EXIT_SUCCESS;
} 
/*****************************************************************************/

int send_message (uint8_t message_id, uint8_t medium, bool encrypt) {
	
	uint32_t checksum;
	struct message_s message;
	uint16_t humidity, temperature;
	uint8_t gpio_inputs, gpio_outputs;

	if (si7006_read_humidity_and_temperature(&humidity, &temperature))
		error();
	
	#ifdef USE_STANDARD_IO
		printf("humidity: %d, temperature: %d\r\n", humidity, temperature);
	#endif
	
	status_gpio_inputs(&gpio_inputs);
	status_gpio_outputs(&gpio_outputs);
	
	message.start = MESSAGE_START;
	
	message.id = message_id;
	
	message.receiver_address_msb = 0x00;
	message.receiver_address_lsb = 0x00;	
	
	message.sender_address_msb = (uint8_t)(microcontroller_name >> 8);
	message.sender_address_lsb = (uint8_t)(microcontroller_name >> 0);

	if (medium == MESSAGE_VIA_RADIO) {
	
		message.counter_msb = (uint8_t)(radio_tx_counter >> 8);
		message.counter_lsb = (uint8_t)(radio_tx_counter >> 0);
		radio_tx_counter++;
	
	} else {
		
		message.counter_msb = (uint8_t)(uart_tx_counter >> 8);
		message.counter_lsb = (uint8_t)(uart_tx_counter >> 0);
		uart_tx_counter++;	
	}
		
	message.var_0 = 0;
	message.var_1 = gpio_inputs;
	message.var_2 = gpio_outputs;
	message.var_3 = 0;
	message.var_4 = 0;
	message.var_5 = (uint8_t)(temperature >> 8);
	message.var_6 = (uint8_t)(temperature >> 1);
	message.var_7 = (uint8_t)(humidity >> 8);
	message.var_8 = (uint8_t)(humidity >> 1);

	if (encrypt == true) {
		
		/* Encrypt bytes id through var_8 */
		if (aes_encrypt(&(message.data[1])))
			return EXIT_FAILURE;
	}
		
	/* Radio will add a CRC bytes at end of each message when transmitting, 
	 * and verify the CRC bytes upon message reception.
	 * Micro controller generated CRC in the message may be used by higher
	 * level system
	 *
	 * Checksum of bytes id through var_8 is added to the message
	 */
	checksum = crc_io_checksum((void*)(&(message.data[1])), 16, CRC_16BIT);
	message.crc_msb = (uint8_t)(checksum >> 8);
	message.crc_lsb = (uint8_t)(checksum >> 0);
	
	message.end = MESSAGE_END;
	
	if (medium == MESSAGE_VIA_RADIO) {
	
		if (radio_send_message(&message))
			return EXIT_FAILURE;
	
	} else {
	
		if (uart_send_message(&message))
			return EXIT_FAILURE;		 
	}
	
	return EXIT_SUCCESS;	
}
/*****************************************************************************/

int generate_microcontroller_name (void) {
	
	uint32_t checksum;
	struct nvm_device_serial device_serial_number;

	nvm_read_device_serial(&device_serial_number);
	
	/* Create an address based on the device serial number */
	checksum = crc_io_checksum(((void*)(&device_serial_number)), 11, CRC_16BIT);

	microcontroller_name = (uint16_t)checksum;
	
	return EXIT_SUCCESS;
}