/*
 * Copyright (c) 2016 - 2017 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef UART_RX_TX_H
#define UART_RX_TX_H

int uart_message_poll (void);
int uart_send_message (struct message_s * tx_message);

#endif /* UART_RX_TX_H */