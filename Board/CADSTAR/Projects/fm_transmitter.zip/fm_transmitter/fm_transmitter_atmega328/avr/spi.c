/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "../fm_transmitter.h"

int spi_init (void) {
	
	OUTPUT(LCD_CHIP_SELECT);
	OUTPUT(LCD_SERIAL_DATA);
	OUTPUT(LCD_CLOCK);

	/* Enable, Master, and SPI mode 3 */
	SPCR = ( (1<<SPE) | (1<<MSTR) | (1<<CPOL) | (1<<CPHA));
	
	/* F_CPU / 2 */
	SPSR = (1<<SPI2X);
	
	return EXIT_SUCCESS;
}

int spi_transmit (char data) {
	
	SPDR = data;
	while(!(SPSR & (1<<SPIF)));
	
	return EXIT_SUCCESS;
}
