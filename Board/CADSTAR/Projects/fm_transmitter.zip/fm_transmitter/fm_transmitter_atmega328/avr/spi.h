/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */


#ifndef SPI_H
#define SPI_H

int spi_init(void);
int spi_transmit(char data);


#endif /* SPI_H */