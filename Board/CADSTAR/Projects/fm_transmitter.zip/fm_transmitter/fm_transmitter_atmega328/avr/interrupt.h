/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#ifndef INTERRUPT_H
#define INTERRUPT_H

void init_interrupts(void);



#endif /* INTERRUPT_H */