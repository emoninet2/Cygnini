/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "fm_transmitter.h"
#include "ndh-c12832a1z/graphic_lcd.h"
#include "si4713/si4713.h"
#include "at42qt1070/at42qt1070.h"
#include "at42qt1070/touch_interface.h"

#define BUFFER_LENGHT 22


/* QT interrupt status */
static volatile bool qt_interrupt_active = false;


enum menues_e {
	MAIN_MENU,
	SUB_MENU_SET_FREQUENCY_MANUAL,
	SUB_MENU_SET_FREQUENCY_AUTO,
};


int last_keypress = TOUCH_NONE;
int current_menu = MAIN_MENU;


void error(void) {
	while(true) {
		TOGGLE(LED);
		_delay_ms(50);
	}
}


static void lcd_write_main_menu(void)
{
	graphic_lcd_clear_screen();
	graphic_lcd_write(0, 0, "ELAB fysisk inst. UiO");
	graphic_lcd_write(1, 0, "Set frequency:");
	graphic_lcd_write(2, 0, "UP -> auto select");
	graphic_lcd_write(3, 0, "OK -> manual set"); 

}

static void wait_for_keypress (void) {
	
	while (!qt_interrupt_active);
	qt_interrupt_active = false;	

	last_keypress = touch_registered();
}


int main (void) {
	
	uint16_t frequency, frequency_best = 0;
	uint8_t rssi, rssi_best = 0xff;
	
	char buf[BUFFER_LENGHT];
	int i;
	
	bool frequency_select = false;
	bool touch_release = false;
	bool scan_complete = true;
	   
	/* Toggle LED if hardware initialization failed */
	if (init_hardware())
		error();
		
	puts("Elektronikklaboratoriet");
	puts("Fysisk Institutt");
	puts("Universitetet i Oslo");
			
	/* Enable graphic display */
	graphic_lcd_clear_screen();
	BACKLIGHT_ON; 
	
	if (si4713_initialize(9650, 115))
		error();	
		
	/* Enable interrupts */
	sei();
	
	/* Print main menu text */
	lcd_write_main_menu();
	
	/* Clear last touch registered */
	last_keypress = touch_registered();

	
	/* Program loop */
	while (true) {
		
		wait_for_keypress();
		
		switch (current_menu) {
			
			default:
			case MAIN_MENU:
			
				switch (last_keypress) {
					
					default:
						break;
					
					case TOUCH_UP:
						
						touch_release = false;
						scan_complete = false;
						current_menu = SUB_MENU_SET_FREQUENCY_AUTO;
						break;
						
		
					case TOUCH_OK:
						
						touch_release = false;
						current_menu = SUB_MENU_SET_FREQUENCY_MANUAL;
						/* Sending on preconfigured frequency */
						graphic_lcd_clear_screen();
						graphic_lcd_write(0, 0, "Select -> LEFT/RIGHT");
						graphic_lcd_write(1, 0, "Confirm -> OK");
							
						frequency = 9650;
						snprintf(buf, BUFFER_LENGHT, "Frequency %6u0 kHz", frequency);
						graphic_lcd_write(3, 0, buf);
						frequency_select = true;

						break;
					
					
					case TOUCH_DOWN:
						/* Back to main menu */
						current_menu = MAIN_MENU;
						lcd_write_main_menu();
						
						break;
						
				}
				break;


			case SUB_MENU_SET_FREQUENCY_AUTO:
					
				if (last_keypress == TOUCH_NONE) {
					touch_release = true;
					_delay_ms(250);
				}
						
				if (touch_release == false)
					break;
							
				switch (last_keypress) {
							
					default:
					case TOUCH_OK:
					case TOUCH_LEFT:
					case TOUCH_RIGHT:
						break;
													
					case TOUCH_DOWN:
						/* Back to main menu */
						current_menu = MAIN_MENU;
						lcd_write_main_menu();
						break;
				}								
							
				if (scan_complete == true)
					break;
	
				graphic_lcd_clear_screen();
				graphic_lcd_write(3, 0, "ELAB fysisk inst. UiO");
				graphic_lcd_write(2, 0, "Scanning         kHz");
				
					
				for (frequency = 8750, i=6; frequency < 10800; frequency += 20, i++) {
					if (si4713_tune_measure(frequency, &rssi))
					error();

					graphic_lcd_write_rssi(0, i, rssi*2);
					snprintf(buf, 6, "%u0", frequency);
					graphic_lcd_write(2, 54, buf);
							
					if (rssi < rssi_best) {
						rssi_best = rssi;
						frequency_best = frequency;			
					}
				}
			
				scan_complete = true;
						
				/* Select frequency with best rssi */
				graphic_lcd_clear_screen();
				snprintf(buf, BUFFER_LENGHT, "Sending on %u0 kHz", frequency_best);
				graphic_lcd_write(0, 0, buf);
				graphic_lcd_write(2, 0, "        ELAB        ");
				graphic_lcd_write(3, 0, "Universitetet i Oslo");	
												
				if (si4713_initialize(frequency_best, 115)) 
					error();
							
				break;	

			case SUB_MENU_SET_FREQUENCY_MANUAL:
				
				if (last_keypress == TOUCH_NONE) {
					touch_release = true;
					_delay_ms(250);
				}
					
				if (touch_release == false)
					break;
					 	
				switch (last_keypress) {
							
					default:
						break;
								
					case TOUCH_OK:
						graphic_lcd_clear_screen();
						snprintf(buf, BUFFER_LENGHT, "Sending on %u0 kHz", frequency);
						graphic_lcd_write(0, 0, buf);
						graphic_lcd_write(2, 0, "        ELAB        ");
						graphic_lcd_write(3, 0, "Universitetet i Oslo");
						frequency_select = false;
						if (si4713_initialize(frequency, 115))
							error();
						break;
							
					case TOUCH_LEFT:
						while(touch_registered() == TOUCH_LEFT) {
							frequency -= 10;
							if (frequency < 8750)
							frequency = 8750;
							snprintf(buf, BUFFER_LENGHT, "Frequency %6u0 kHz", frequency);
							graphic_lcd_write(3, 0, buf);
							_delay_ms(200);
						}
						break;
							
					case TOUCH_RIGHT:
						while(touch_registered() == TOUCH_RIGHT) {
							frequency += 10;
							if (frequency > 10800)
							frequency = 10800;
							snprintf(buf, BUFFER_LENGHT, "Frequency %6u0 kHz", frequency);
							graphic_lcd_write(3, 0, buf);
							_delay_ms(200);
						}
						break;
					
					case TOUCH_DOWN:
						/* Back to main menu */
						current_menu = MAIN_MENU;
						lcd_write_main_menu();
					
						break;			
				}
			}
		/* Wait before accepting new key press */	
		_delay_ms(500);	
	}
	
}

ISR (QT_TOUCH_INTERRUPT_VECTOR) {
	TOGGLE(LED);
	qt_interrupt_active = true;
	
	if (touch_registered() == TOUCH_UP)
		HIGH(LED_PAD_UP);
		
	if (touch_registered() == TOUCH_LEFT)
		HIGH(LED_PAD_LEFT);
	
	if (touch_registered() == TOUCH_OK)
		HIGH(LED_PAD_OK);
	
	if (touch_registered() == TOUCH_RIGHT)
		HIGH(LED_PAD_RIGHT);
		
	if (touch_registered() == TOUCH_DOWN)
		HIGH(LED_PAD_DOWN);
	
	if (touch_registered() == TOUCH_NONE) {
		LOW(LED_PAD_UP);
		LOW(LED_PAD_OK);
		LOW(LED_PAD_DOWN);
		LOW(LED_PAD_RIGHT);
		LOW(LED_PAD_LEFT);
	}
		
		
	
}