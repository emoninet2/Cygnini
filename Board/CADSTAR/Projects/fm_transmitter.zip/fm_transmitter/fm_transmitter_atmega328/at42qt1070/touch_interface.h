/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#ifndef TOUCH_INTERFACE_H
#define TOUCH_INTERFACE_H

int touch_registered(void);

/* Touch pad mapping to QT device key */
enum {
	TOUCH_GUARD_RING,
	TOUCH_UP,
	TOUCH_LEFT,
	TOUCH_OK,
	TOUCH_RIGHT,
	TOUCH_DOWN,
	TOUCH_NONE,
};


#endif /* TOUCH_INTERFACE_H */