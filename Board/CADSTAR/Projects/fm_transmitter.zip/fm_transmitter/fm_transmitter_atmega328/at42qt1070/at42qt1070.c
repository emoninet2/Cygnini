/******************************************************************************* 
*   $FILE:  QT_I2C.c
*   Brief: Application interfaces to drive the QT device 
*   Atmel Corporation:  http://www.atmel.com
*   Support email:  touch@atmel.com
******************************************************************************/
/*  License
*   Copyright (c) 2012, Atmel Corporation All rights reserved.
*   
*   Redistribution and use in source and binary forms, with or without
*   modification, are permitted provided that the following conditions are met:
*   
*   1. Redistributions of source code must retain the above copyright notice,
*   this list of conditions and the following disclaimer.
*   
*   2. Redistributions in binary form must reproduce the above copyright notice,
*   this list of conditions and the following disclaimer in the documentation
*   and/or other materials provided with the distribution.
*   
*   3. The name of ATMEL may not be used to endorse or promote products derived
*   from this software without specific prior written permission.
*   
*   THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
*   WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
*   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
*   SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
*   INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*   (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*   LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
*   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
*   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
*   THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* MODIFIED BY ELAB ! */

#include "../fm_transmitter.h"
#include "at42qt1070.h"
#include "../avr/i2c.h"

static int ReadSetupBlock(uint8_t ReadLength, uint8_t *ReadPtr);
static int WriteSetupBlock(uint8_t WriteLength, uint8_t *WritePtr);

/* Setup block structure */
setup_block_t setup_block;

int read_key_status(uint8_t data_lenght, uint8_t *data) {
	
	/* Read detection status of all keys */
	if (i2c_read_reg(QT_I2C_ADDRESS, QT_STATUS_ADDR, data, data_lenght))
		return EXIT_FAILURE;

	return EXIT_SUCCESS;	
}

int init_at42qt1070(void) {
	
	uint8_t chip_id;
	
	/* Reset QT device */
	LOW(QT_RESET_PIN);
  
	/* The reset pin must be low at least 10us to cause a reset */
	_delay_ms(10);
  
	/* Pull line back to high to resume normal operation */ 
	HIGH(QT_RESET_PIN);
	
	_delay_ms(100);
	
	/* Check communication is ready and able to read Chip ID */
	if (i2c_read_reg(QT_I2C_ADDRESS, QT_CHIP_ID, &chip_id, 1))
		return EXIT_FAILURE;

	/* Check that the responding device is a intended device */
	if (chip_id != QT_DEVICE_ID)
		return EXIT_FAILURE;
	
    /* Read setup block */
    if (ReadSetupBlock(sizeof(setup_block), (uint8_t *)&setup_block))
		return EXIT_FAILURE;
			    
    /* TO DO : modify setup block parameters here
     * from default valus if required 
     * For example: To set NTHR for Key 0 to 20
     * setup_block.key0_NTHR = 20; 
     */

	/* Write setup block */
	if (WriteSetupBlock(sizeof(setup_block),(uint8_t *)&setup_block))
		return EXIT_FAILURE;
		
	/* Enable interrupt */
	QT_TOUCH_INTERRUPT_ENABLE;
		
	return EXIT_SUCCESS;		
}	

static int ReadSetupBlock(uint8_t ReadLength, uint8_t *ReadPtr)
{
	/* Read setup block */
	if (i2c_read_reg(QT_I2C_ADDRESS, QT_SETUPS_BLOCK_ADDR, ReadPtr, ReadLength))
		return EXIT_FAILURE;

	return EXIT_SUCCESS;
}		

static int WriteSetupBlock(uint8_t WriteLength, uint8_t *WritePtr)
{	
	/* write setup block */
	if (i2c_write_reg(QT_I2C_ADDRESS, QT_SETUPS_BLOCK_ADDR, WritePtr, WriteLength))
		return EXIT_FAILURE;

	return EXIT_SUCCESS;	
}
