
/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "../fm_transmitter.h"
#include "touch_interface.h"
#include "at42qt1070.h"

/* Application storage for QT device-status */
static uint8_t qt_status[QT_STATUS_SIZE];

int touch_registered(void) {

	read_key_status(sizeof(qt_status), qt_status);
	
	if (qt_status[0] != 0x01)
		return TOUCH_NONE;
		
	if (qt_status[1] == 0x02)
		return TOUCH_UP;
		
	if (qt_status[1] == 0x04)
		return TOUCH_LEFT;
		
	if (qt_status[1] == 0x10)
		return TOUCH_RIGHT;
		
	if (qt_status[1] == 0x20)
		return TOUCH_DOWN;
		
	if (qt_status[1] == 0x08)
		return TOUCH_OK;						
	
	return TOUCH_NONE;
}