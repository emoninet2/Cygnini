/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "../fm_transmitter.h"
#include "si4713.h"
#include "../avr/i2c.h"

static int si4713_tune_status (uint8_t *frequency, uint8_t *power_level, \
							   uint8_t *antenna_tuning_capacitor, \
							   uint8_t *received_noise_level);
static int si4713_wait_for_STC_bit (void);
static int si4713_tune_frequency (uint16_t frequency);
static int si4713_set_power (uint8_t power_level, uint8_t antenna_tuning_capacitor);
static int si4713_reset (void);
static int si4713_power_up (void);
static int si4713_enable_rds (void);
static int si4713_set_property (uint16_t property, uint16_t value);
static int si4713_read_register (uint8_t reg, uint8_t *data, uint8_t lenght);
static int si4713_write_register (uint8_t reg, uint8_t *data, uint8_t lenght);

int si4713_tune_measure(uint16_t frequency, uint8_t *rssi) {
	
	uint8_t data[] = {0, (frequency >> 8), (frequency & 0xff), 0, 0};
		 
	if (si4713_write_register(SI4713_CMD_TX_TUNE_MEASURE, data, 4))
		return EXIT_FAILURE;
	
	_delay_ms(200);		
		
	if (si4713_tune_status (&data[0], &data[2], &data[3], &data[4]))
		return EXIT_FAILURE;
		
	if ((uint16_t)((data[0] << 8) | data[1]) != frequency)
		return EXIT_FAILURE;
		
	*rssi = data[4];		
			
	return EXIT_SUCCESS;	
}

int si4713_initialize(uint16_t frequency, uint8_t power_level) {
	
	uint8_t data[9];
	
	/* Hard reset */
	si4713_reset();

	/* Power up and configure */
	if (si4713_power_up())
		return EXIT_FAILURE;

	/* Verify chip revision */
	data[0] = 0;
	if (si4713_write_register (SI4713_CMD_GET_REV, data, 1))
		return EXIT_FAILURE;
		
	if (si4713_read_register (SI4713_CMD_GET_REV, data, 9))
		return EXIT_FAILURE;
		
	if (data[8] != 0x42)
		return EXIT_FAILURE;
	
	/* Set transmission frequency */
	if (si4713_tune_frequency (frequency))
		return EXIT_FAILURE;
		
	/* Wait for STC bit set */
	if (si4713_wait_for_STC_bit())
		return EXIT_FAILURE;
				
	/* Check TX tune status */
	if (si4713_tune_status (&data[0], &data[2], &data[3], &data[4]))
		return EXIT_FAILURE;
		
	if ((uint16_t)((data[0] << 8) | data[1]) != frequency)
		return EXIT_FAILURE;

	/* Set radio output level */
	if (si4713_set_power(power_level, 0))
		return EXIT_FAILURE;	

	/* Wait for STC bit set */
	if (si4713_wait_for_STC_bit())
		return EXIT_FAILURE;
				
	/* Check TX tune status */
	if (si4713_tune_status (&data[0], &data[2], &data[3], &data[4]))
		return EXIT_FAILURE;
		
	/* Enable RDS */
	if (si4713_enable_rds())
		return EXIT_FAILURE;		

	return EXIT_SUCCESS;	
}

static int si4713_wait_for_STC_bit(void) {
	
	int i = 100;
	uint8_t data[1];
	
	while (i) {
		
		_delay_ms(10);
		
		data[0] = 0;
		if (si4713_write_register (SI4713_CMD_GET_INT_STATUS, data, 1))
			return EXIT_FAILURE;
		
		if (si4713_read_register (SI4713_CMD_GET_INT_STATUS, data, 1))
			return EXIT_FAILURE;
		
		if (data[0] & 0x01)
			return EXIT_SUCCESS;
		
		i--;		
	}
	
	return EXIT_FAILURE;		
}

static int si4713_tune_status (uint8_t *frequency, uint8_t *power_level, \
							  uint8_t *antenna_tuning_capacitor, \
							  uint8_t *received_noise_level) {

	uint8_t data[] = {0x01, 0, 0, 0, 0, 0, 0, 0};

	if (si4713_write_register (SI4713_CMD_TX_TUNE_STATUS, data, 1))
		return EXIT_FAILURE;
		
	if (si4713_read_register (SI4713_CMD_TX_TUNE_STATUS, data, 8))
		return EXIT_FAILURE;
		
	*frequency = data[2];
	*(frequency + 1) = data[3];
	*power_level = data[5];
	*antenna_tuning_capacitor = data[6];
	*received_noise_level = data[7];
		
	return EXIT_SUCCESS;	
}

static int si4713_tune_frequency (uint16_t frequency) {

	uint8_t data[] = {0, (frequency >> 8), (frequency & 0xff)}; 
	if (si4713_write_register(SI4713_CMD_TX_TUNE_FREQ, data, 3))
		return EXIT_FAILURE;
			
	return EXIT_SUCCESS;	
}

static int si4713_set_power (uint8_t power_level, uint8_t antenna_tuning_capacitor) {

	uint8_t data[] = {0, 0, power_level, antenna_tuning_capacitor}; 
	if (si4713_write_register(SI4713_CMD_TX_TUNE_POWER, data, 3))
		return EXIT_FAILURE;
			
	return EXIT_SUCCESS;	
}

static int si4713_power_up (void) {
	/*
	 * CTS interrupt disabled
	 * GPO2 output disabled
	 * Boot normally
	 * Xtal oscillator enabled
	 * FM transmit	
	 * Analog input mode
	 */
	uint8_t data[] = {0x12, 0x50}; 
	if (si4713_write_register(SI4713_CMD_POWER_UP, data, 2))
		return EXIT_FAILURE;
		
	/* Set tx preephasis to 50us as used in Europe */
	if (si4713_set_property(SI4713_PROP_TX_PREEMPHASIS, 0x0001 ))
		return EXIT_FAILURE;
		
	_delay_ms(100);	
	return EXIT_SUCCESS;	
}

static int si4713_set_rds_station (char *s) {
	
	uint8_t data[50], i, len = strlen(s);
	uint8_t slots = (len+3) / 4;

	for (i=0; i<slots; i++) {
		memset(data, ' ', 5);
		memcpy((data+1), s, ((strlen(s) > 4) ? strlen(s) : 4));
		s+=4;
		data[0] = i;
		data[5] = 0;		
		if (si4713_write_register(SI4713_CMD_TX_RDS_PS, data, 5))
			return EXIT_FAILURE;
	}
	
	return EXIT_SUCCESS;
}

static int si4713_set_rds_buffer (char *s) {
	
	uint8_t data[50], i, len = strlen(s);
	uint8_t slots = (len+3) / 4;

	for (i=0; i<slots; i++) {
		memset(data, ' ', 7);
		memcpy(data+3, s, ((strlen(s) > 4) ? strlen(s) : 4));
		s+=4;
		data[7] = 0;
		
		if (i == 0) {
			data[0] = 0x06;
		
		} else {
			data[0] = 0x04;
		}
		
		data[1] = 0x20;
		data[2] = i;
		
		if (si4713_write_register(SI4713_CMD_TX_RDS_BUFF, data, 7))
			return EXIT_FAILURE;		
	}
	
	return EXIT_SUCCESS;
}

static int si4713_enable_rds (void) {

	/* (default is 68.25) */
	si4713_set_property(SI4713_PROP_TX_AUDIO_DEVIATION, 6825);
	
	/* (default is 2KHz) */
	si4713_set_property(SI4713_PROP_TX_RDS_DEVIATION, 200);

	 /* RDS IRQ */
	si4713_set_property(SI4713_PROP_TX_RDS_INTERRUPT_SOURCE, 0x0001);
	
	/* program identifier */
	si4713_set_property(SI4713_PROP_TX_RDS_PI, 0);
	
	/* 50% mix (default) */
	si4713_set_property(SI4713_PROP_TX_RDS_PS_MIX, 0x03);
	
	/* RDSD0 & RDSMS (default) */
	si4713_set_property(SI4713_PROP_TX_RDS_PS_MISC, 0x1808);
	
	/* 3 repeats (default) */
	si4713_set_property(SI4713_PROP_TX_RDS_PS_REPEAT_COUNT, 3);

	si4713_set_property(SI4713_PROP_TX_RDS_MESSAGE_COUNT, 1);
	
	/* No AF */
	si4713_set_property(SI4713_PROP_TX_RDS_PS_AF, 0xE0E0);
	si4713_set_property(SI4713_PROP_TX_RDS_FIFO_SIZE, 0);

	si4713_set_property(SI4713_PROP_TX_COMPONENT_ENABLE, 0x0007);
	
	/* Set RDS station */
	if (si4713_set_rds_station ("ELAB UiO"))
		return EXIT_FAILURE;
			
	/* Set RDS buffer */
	if (si4713_set_rds_buffer("FM brought to you by ELAB"))
		return EXIT_FAILURE;
	
	return EXIT_SUCCESS;	
}


static int si4713_reset (void) {

	LOW(FM_RESET_PIN);
	_delay_ms(100);
	HIGH(FM_RESET_PIN);
	_delay_ms(100);
	
	return EXIT_SUCCESS;	
}

static int si4713_set_property (uint16_t property, uint16_t value) {
	
	uint8_t data[] = {0, (property >> 8), (property & 0xff), \
		                 (value >> 8), (value & 0xff) }; 
	if (si4713_write_register(SI4713_CMD_SET_PROPERTY, data, 5))
		return EXIT_FAILURE;		
	
	return EXIT_SUCCESS;	
}

static int si4713_write_register (uint8_t reg, uint8_t *data, uint8_t lenght) {

	if (i2c_write_reg (SI4713_ADDRESS, reg, data, lenght))
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}

static int si4713_read_register (uint8_t reg, uint8_t *data, uint8_t lenght) {

	if (i2c_read_reg (SI4713_ADDRESS, reg, data, lenght))
		return EXIT_FAILURE;
		
	return EXIT_SUCCESS;
}	