/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#include "fm_transmitter.h"
#include "avr/uart.h"
#include "avr/spi.h"
#include "avr/i2c.h"
#include "ndh-c12832a1z/st7565r.h"
#include "at42qt1070/at42qt1070.h"

int init_hardware(void) {
	
	/* Wait for voltages to stabilize */
	_delay_ms(500);

	/* Redirecting STDIN and STDOUT to UART */
	uart_init();
	stdout = &uart_output;
	stdin = &uart_input;
	
	/* Configure connection to indicator LED as output*/
	OUTPUT(LED);
	
	/* Configure pad indication LEDs as outputs */
	OUTPUT(LED_PAD_UP);
	OUTPUT(LED_PAD_OK);
	OUTPUT(LED_PAD_DOWN);
	OUTPUT(LED_PAD_RIGHT);
	OUTPUT(LED_PAD_LEFT);
		
	/* SPI connection to graphic LCD display */
	if (spi_init())
		return EXIT_FAILURE;
	
	/* LCD display connections */
	OUTPUT(LCD_RESET);
	OUTPUT(LCD_A0);
	OUTPUT(BACKLIGHT);	
	
	/* Configure graphic LCD display controller */
	if (st7565r_init())
		return EXIT_FAILURE;
		
	/* I2C connection to radio transmitter */
	if (i2c_init())
		return EXIT_FAILURE;
	
	/* Radio transmitter connections in addition to I2C */
	OUTPUT(FM_RESET_PIN);	
		
	/* Configure QT touch device */
	INPUT(QT_TOUCH_INTERRUPT);
	OUTPUT(QT_RESET_PIN);	

	if (init_at42qt1070())
		return EXIT_FAILURE; 

	return EXIT_SUCCESS;
}
	
