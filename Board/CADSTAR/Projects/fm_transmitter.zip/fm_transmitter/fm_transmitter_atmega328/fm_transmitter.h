/*
 * Copyright (c) 2015 - 2016 Elektronikklaboratoriet
 *                           Fysisk Institutt
 *                           Universitetet i Oslo
 *
 *							 All rights reserved
 */

#ifndef FM_TRANSMITTER
#define FM_TRANSMITTER

#include <inttypes.h>

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define F_CPU	(1000000UL)
#define BAUD	(9600)

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include <util/twi.h>
#include <util/delay.h>
#include <util/setbaud.h>

#define I_SET(type,name,bit)		type ## name  |= _BV(bit)    
#define I_CLEAR(type,name,bit)		type ## name  &= ~ _BV(bit)        
#define I_TOGGLE(type,name,bit)		type ## name  ^= _BV(bit)    
#define I_GET(type,name,bit)		((type ## name >> bit) &  1)
#define I_PUT(type,name,bit,value)	type ## name = ( type ## name & ( ~ _BV(bit)) ) | ( ( 1 & (unsigned char)value ) << bit )

#define OUTPUT(pin)					I_SET(DDR,pin)    
#define INPUT(pin)					I_CLEAR(DDR,pin)    
#define HIGH(pin)					I_SET(PORT,pin)
#define LOW(pin)					I_CLEAR(PORT,pin)    
#define TOGGLE(pin)					I_TOGGLE(PORT,pin)    
#define READ(pin)					I_GET(PIN,pin)
		
/* Port B */
#define	LCD_RESET					B,0
#define	LCD_A0						B,1
#define	LCD_CHIP_SELECT				B,2
#define LCD_SERIAL_DATA				B,3
#define	LCD_CLOCK					B,5		

#define LED_PAD_LEFT				B,7
#define LED_PAD_LEFT_ON				HIGH(LED_PAD_LEFT)
#define LED_PAD_LEFT_OFF			LOW(LED_PAD_LEFT)				

/* Port C */						
#define LED							C,0
#define LED_ON						HIGH(LED)
#define LED_OFF						LOW(LED)

#define QT_RESET_PIN				C,2
					
#define FM_RESET_PIN				C,3

/* Port D */
#define QT_TOUCH_INTERRUPT			D,2
#define QT_TOUCH_INTERRUPT_VECTOR   INT0_vect
#define QT_TOUCH_INTERRUPT_ENABLE	do { \
										EICRA = (1<<ISC01); \
										EIMSK = (1<<INT0); \
									} while (0)


#define LED_PAD_UP					D,3
#define LED_PAD_UP_ON				HIGH(LED_PAD_UP)
#define LED_PAD_UP_OFF				LOW(LED_PAD_UP)

#define LED_PAD_OK					D,4
#define LED_PAD_OK_ON				HIGH(LED_PAD_OK)
#define LED_PAD_OK_OFF				LOW(LED_PAD_OK)

#define LED_PAD_DOWN				D,5
#define LED_PAD_DOWN_ON				HIGH(LED_PAD_DOWN)
#define LED_PAD_DOWN_OFF			LOW(LED_PAD_DOWN)

#define LED_PAD_RIGHT				D,6
#define LED_PAD_RIGHT_ON			HIGH(LED_PAD_RIGHT)
#define LED_PAD_RIGHT_OFF			LOW(LED_PAD_RIGHT)

#define	BACKLIGHT					D,7
#define BACKLIGHT_ON				HIGH(BACKLIGHT)
#define BACKLIGHT_OFF				LOW(BACKLIGHT)

int init_hardware(void);

#endif /* FM_TRANSMITTER */